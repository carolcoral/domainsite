# DomainSite
> 售卖域名的展示站

* Demo site: https://cnkj.site
* 支持中英文双语切换
* 支持明暗样式切换
* 后续可能会改成vue框架方式方便直接 `config.json` 方式配置部署
